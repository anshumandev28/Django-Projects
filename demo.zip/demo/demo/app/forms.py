from secrets import choice

from django import forms
from .models import User



class StudentRegistration(forms.ModelForm):
    # Employee= forms.CharField(widget=forms.Select(choices=EMP_CHOICES))
    class Meta:
        model=User
        fields=['emp','emp_name','title','email','description']
        widgets={
            'emp': forms.Select(attrs={'class':'form-control p-2 mt-2'}),
            'emp_name': forms.TextInput(attrs={'class':'form-control p-2 mt-2'}),
            'title':forms.TextInput(attrs={'class':'form-control p-2 mt-2'}),
            'email':forms.EmailInput(attrs={'class':'form-control p-2 mt-2'}),
            'description':forms.TextInput(attrs={'class':'form-control p-2 mt-2'}),

        }
